package com.springsecurity.springsecurity.controller;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @GetMapping("/public")
    public String publicPage() {
        return "Public endpoint";
    }

    @GetMapping("/private")
    public String privatePage(Authentication auth) {
        return "Hello " + auth.getName() + ", this is a protected endpoint!";
    }
}
